﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculaFgts_Click(object sender, EventArgs e)
        {
            var salario = decimal.Parse(txtSalarioBruto.Text);
            var fgts = salario * 8 /100;
            lblResultado.Text = "R$ " + fgts.ToString();
            panelResultado.Visible = true;
            panelResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(183)))), ((int)(((byte)(241)))));
        }
    }
}
